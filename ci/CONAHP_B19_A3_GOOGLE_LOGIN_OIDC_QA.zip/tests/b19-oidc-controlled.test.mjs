/** B19-A3: local, in-memory OIDC authorization code provider exercised through actual
 * @auth/core@0.41.3 Auth(Request, config). Never forwards HTTP to Google.
 * This is synthetic IdP integration, NOT a Google-OAuth-device acceptance test.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash, createPublicKey, generateKeyPairSync, sign, verify} from 'node:crypto';
import {Auth, customFetch} from '@auth/core';
import Google from '@auth/core/providers/google';
import {decode, encode} from '@auth/core/jwt';
import {makeAuthConfig, handleMe, handlePreferences} from '../lib/b19-core.mjs';

const origin='https://qa.example.invalid';
const issuer='https://accounts.google.com';
const idp='https://oidc-fixture.example.invalid';
const sub='100000000000000000001';
const email='qa@example.invalid';
const clientId='synthetic-oidc-client';
const env={APP_ORIGIN:origin, AUTH_SECRET:'a'.repeat(64), AUTH_GOOGLE_ID:clientId,
  AUTH_GOOGLE_SECRET:'synthetic-server-secret',
  CONAHP_GOOGLE_BINDINGS_JSON:JSON.stringify([{sub,email,profileId:'flora'}])};
const name='__Host-conahp.session-token';
const pair=generateKeyPairSync('rsa',{modulusLength:2048});
const b64=(v)=>Buffer.from(typeof v==='string'?v:JSON.stringify(v)).toString('base64url');
const sha256s256=(v)=>createHash('sha256').update(v).digest('base64url');
const json=(obj,status=200)=>new Response(JSON.stringify(obj),{status,headers:{'content-type':'application/json','cache-control':'no-store',pragma:'no-cache'}});
const req=(path,init={})=>new Request(origin+path,init);
const newCookies=(res)=>res.headers.getSetCookie?.()||[res.headers.get('set-cookie')].filter(Boolean);
const ownCookie=(res,key)=>newCookies(res).find(c=>c.startsWith(key+'='))?.split(';',1)[0];
const sessionIsIssued=(res)=>newCookies(res).some(c=>c.startsWith(name+'=')&&!/max-age=0/i.test(c));
function jwt(claims){
 const input=b64({alg:'RS256',typ:'JWT',kid:'local-test-rsa'})+'.'+b64(claims);
 const signature=sign('RSA-SHA256',Buffer.from(input),pair.privateKey).toString('base64url');
 const compact=input+'.'+signature;
 // Independently validate our test fixture. Auth.js/OAuth4WebAPI process the ID Token
 // received from the trusted HTTPS token endpoint; do NOT misclaim that they check
 // its JWS signature in this particular authorization-code flow.
 assert.equal(verify('RSA-SHA256',Buffer.from(input),pair.publicKey,Buffer.from(signature,'base64url')),true);
 return compact;
}
class Jar {
 constructor(){this.map=new Map();}
 take(res){for(const item of newCookies(res)){
   const part=item.split(';',1)[0],pos=part.indexOf('=');if(pos<0)continue;
   const key=part.slice(0,pos), val=part.slice(pos+1);
   if(/max-age=0/i.test(item)||/expires=Thu, 01 Jan 1970/i.test(item)||!val)this.map.delete(key);
   else this.map.set(key,val);
 }}
 has(part){return [...this.map.keys()].some(n=>n.includes(part));}
 find(part){return [...this.map.keys()].find(n=>n.includes(part));}
 remove(part){const n=this.find(part);assert.ok(n,`Expected a ${part} cookie`);this.map.delete(n);}
 async reseal(part,value){const key=this.find(part);assert.ok(key,`Expected cookie ${part}`);
   this.map.set(key,await encode({token:{provider:'google',value},secret:env.AUTH_SECRET,salt:key,maxAge:900}));
 }
 toHeader(){return [...this.map].map(([k,v])=>`${k}=${v}`).join('; ');}
 with(headers={}){return {...headers,cookie:this.toHeader()};}
 clone(){const out=new Jar();out.map=new Map(this.map);return out;}
}
const failureMessage=(err)=>[err?.name,err?.message,err?.cause?.name,err?.cause?.message,err?.cause?.err?.name,err?.cause?.err?.message].filter(Boolean).join(' | ');
function controlledIdp({nonceOverride, audOverride, issuerOverride}={}){
 const data={discovery:0,jwks:0,token:0,successfulTokens:0,attempts:[],fetches:[],codes:new Map(),lastIdToken:null};
 const tokenOf=(url,init)=>new Request(url,init);
 const custom=async(input,init={})=>{
   const url=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url);
   data.fetches.push(url.href);
   if(url.href===issuer+'/.well-known/openid-configuration'){
     data.discovery++;
     return json({issuer,authorization_endpoint:idp+'/authorize',token_endpoint:idp+'/token',
       userinfo_endpoint:idp+'/userinfo',jwks_uri:idp+'/jwks',response_types_supported:['code'],
       subject_types_supported:['public'],id_token_signing_alg_values_supported:['RS256'],
       code_challenge_methods_supported:['S256'],token_endpoint_auth_methods_supported:['client_secret_basic']});
   }
   if(url.href===idp+'/jwks'){
     data.jwks++;
     return json({keys:[{...pair.publicKey.export({format:'jwk'}),kid:'local-test-rsa',use:'sig',alg:'RS256'}]});
   }
   if(url.href===idp+'/token'){
     data.token++;
     let form;
     if(input instanceof Request){form=new URLSearchParams(await input.clone().text());}
     else if(init.body instanceof URLSearchParams){form=init.body;}
     else {form=new URLSearchParams(await tokenOf(url,init).text());}
     const code=form.get('code'),verifier=form.get('code_verifier');
     const record=data.codes.get(code);
     data.attempts.push({code,verifierPresent:!!verifier,verifierMatch:!!record&&sha256s256(verifier||'')===record.challenge,replayed:!!record?.used});
     if(!record||record.used||!verifier||sha256s256(verifier)!==record.challenge)
       return json({error:'invalid_grant',error_description:'one-time code invalid or PKCE S256 mismatch'},400);
     record.used=true;data.successfulTokens++;
     const now=Math.floor(Date.now()/1000);
     data.lastIdToken=jwt({iss:issuerOverride??issuer,aud:audOverride??clientId,sub,email,email_verified:true,
       nonce:nonceOverride??record.nonce,iat:now,exp:now+3600,name:'Synthetic QA'});
     return json({access_token:'local-controlled-access',token_type:'Bearer',expires_in:3600,
       id_token:data.lastIdToken});
   }
   throw new Error(`UNEXPECTED_OIDC_FETCH: ${url.href}`);
 };
 data.customFetch=custom;
 data.issue=(url)=>{
   const code=`fixture-code-${data.codes.size+1}`;
   data.codes.set(code,{challenge:url.searchParams.get('code_challenge'),nonce:url.searchParams.get('nonce'),used:false});
   return code;
 };
 return data;
}
function makeFixture(options={}){
 const idpState=controlledIdp(options), logs=[];
 const config=makeAuthConfig(env,Google);
 // Auth.js Google(options) wraps its options in provider.options, then its
 // provider normalizer forwards this documented framework-level test-only hook.
 assert.deepEqual(config.providers[0].options.checks,['pkce','state','nonce']);
 config.providers[0].options[customFetch]=idpState.customFetch;
 config.logger={error(error){logs.push(failureMessage(error));},warn(){},debug(){}};
 const send=(path,init={})=>Auth(req(path,init),config);
 return {idp:idpState,config,send,logs,jar:new Jar()};
}
async function start(f){
 const csrf=await f.send('/api/auth/csrf');
 assert.equal(csrf.status,200);
 f.jar.take(csrf);
 const {csrfToken}=await csrf.json();
 assert.ok(f.jar.has('csrf-token'),'Auth.js CSRF cookie must be present');
 const response=await f.send('/api/auth/signin/google',{method:'POST',
   headers:f.jar.with({'content-type':'application/x-www-form-urlencoded',origin}),
   body:new URLSearchParams({csrfToken,callbackUrl:origin+'/'}).toString()});
 f.jar.take(response);
 let href=response.headers.get('location');
 if(!href&&response.headers.get('content-type')?.includes('json'))href=(await response.json()).url;
 assert.ok(href,`Missing authorize redirect (status ${response.status}), errors=${f.logs.join(' / ')}`);
 const url=new URL(href);
 assert.equal(url.origin,idp);
 assert.equal(url.pathname,'/authorize');
 assert.equal(url.searchParams.get('code_challenge_method'),'S256');
 const challenge=url.searchParams.get('code_challenge');
 const state=url.searchParams.get('state'),nonce=url.searchParams.get('nonce');
 for(const [label,value] of [['state',state],['nonce',nonce],['code_challenge',challenge]])
   assert.ok(value?.length>20,`Missing ${label}`);
 for(const part of ['state','nonce','pkce.code_verifier'])assert.ok(f.jar.has(part),`Missing protected ${part} cookie`);
 for(const [part,expected] of [['state',state],['nonce',nonce]]){
   const key=f.jar.find(part);const value=await decode({token:f.jar.map.get(key),secret:env.AUTH_SECRET,salt:key});
   assert.equal(value.provider,'google');assert.equal(value.value,expected,`${part} must be sealed to its query value`);
 }
 const pkceKey=f.jar.find('pkce.code_verifier');
 const sealed=await decode({token:f.jar.map.get(pkceKey),secret:env.AUTH_SECRET,salt:pkceKey});
 assert.equal(sealed.provider,'google');
 assert.equal(sha256s256(sealed.value),challenge,'PKCE S256 challenge must match sealed verifier');
 // The signin endpoint DID perform discovery through our stub, not a network exception.
 assert.equal(f.idp.discovery,1);
 return {url,code:f.idp.issue(url),state,nonce};
}
async function callback(f,flow,override={}){
 const jar=override.jar??f.jar;
 const code=override.code??flow.code;
 const state=override.state??flow.state;
 const path=`/api/auth/callback/google?${new URLSearchParams({code,state}).toString()}`;
 return f.send(path,{headers:jar.with()});
}
function noPositiveSession(res){assert.equal(sessionIsIssued(res),false,`No authenticated cookie expected, status ${res.status}`);}
async function proveSuccess(f,flow){
 const response=await callback(f,flow);
 assert.equal(f.idp.token,1,`Token endpoint must be reached after correct checks; logs: ${f.logs.join(' / ')}`);
 assert.equal(f.idp.successfulTokens,1);
 assert.ok(sessionIsIssued(response),`Auth.js should issue session cookie, status ${response.status}, errors ${f.logs.join(' / ')}`);
 const tokenCookie=ownCookie(response,name);assert.ok(tokenCookie);
 const decoded=await decode({token:tokenCookie.split('=',2)[1],secret:env.AUTH_SECRET,salt:name});
 assert.equal(decoded.authProvider,'google');assert.equal(decoded.googleSub,sub);assert.equal(decoded.googleVerified,true);
 const me=await handleMe(req('/api/me?profile=juliana',{headers:{cookie:tokenCookie,'x-google-email':'fake@example.invalid'}}),env,decode);
 assert.equal(me.status,200);assert.equal((await me.json()).profile.id,'flora');
 const prefs=await handlePreferences(req('/api/preferences',{headers:{cookie:tokenCookie}}),env,decode);
 assert.equal(prefs.status,503);assert.equal((await prefs.json()).error.code,'PERSISTENCE_NOT_CONFIGURED');
 return {response,tokenCookie};
}

test('OIDC controlled positive: code/state/nonce/PKCE S256 -> callback -> authorized session',async()=>{
 const f=makeFixture(),flow=await start(f);
 const result=await proveSuccess(f,flow);
 assert.equal(f.idp.attempts[0].verifierMatch,true);
 const jwks=await (await f.idp.customFetch(idp+'/jwks')).json();
 assert.equal(f.idp.jwks,1);assert.equal(jwks.keys[0].kid,'local-test-rsa');
 const [head,claims,signature]=f.idp.lastIdToken.split('.');
 assert.equal(verify('RSA-SHA256',Buffer.from(head+'.'+claims),
   createPublicKey({key:jwks.keys[0],format:'jwk'}),Buffer.from(signature,'base64url')),true,
   'Synthetic IdP JWKS matches its signed test fixture');
 // Auth.js uses authenticated token endpoint transport and verifies OIDC claims;
 // the independent test fixture signature check is NOT attributed to Auth.js.
 assert.equal(result.response.headers.get('location')?.startsWith(origin)??true,true);
});

test('OIDC state query tampered: discovered OK, state comparison fails before token exchange',async()=>{
 const f=makeFixture(),flow=await start(f);
 const r=await callback(f,flow,{state:flow.state+'tampered'});
 noPositiveSession(r);assert.ok(f.idp.discovery>=2);assert.equal(f.idp.token,0);
});
test('OIDC state cookie absent: isolated state failure before PKCE/token',async()=>{
 const f=makeFixture(),flow=await start(f);f.jar.remove('state');
 const r=await callback(f,flow);noPositiveSession(r);
 assert.ok(f.idp.discovery>=2);assert.equal(f.idp.token,0);
});
test('OIDC PKCE cookie absent: state consumed and grant not exchanged',async()=>{
 const f=makeFixture(),flow=await start(f);f.jar.remove('pkce.code_verifier');
 const r=await callback(f,flow);noPositiveSession(r);
 assert.ok(f.idp.discovery>=2);assert.equal(f.idp.token,0);
 // The correctly matched state and valid nonce/verifier are held constant;
 // discovery succeeded, but the token endpoint was not called.
});
test('OIDC altered but valid PKCE cookie: token endpoint independently rejects wrong S256 verifier',async()=>{
 const f=makeFixture(),flow=await start(f);await f.jar.reseal('pkce.code_verifier','incorrect-verifier-synthetic');
 const r=await callback(f,flow);noPositiveSession(r);
 assert.ok(f.idp.discovery>=2);assert.equal(f.idp.token,1);
 assert.equal(f.idp.attempts[0].verifierMatch,false);
 assert.equal(f.idp.successfulTokens,0);
});
test('OIDC nonce cookie absent: valid grant reached, rejection at nonce processing',async()=>{
 const f=makeFixture(),flow=await start(f);f.jar.remove('nonce');
 const r=await callback(f,flow);noPositiveSession(r);
 assert.ok(f.idp.discovery>=2);assert.equal(f.idp.token,1);
 assert.equal(f.idp.attempts[0].verifierMatch,true);
 assert.equal(f.idp.successfulTokens,1);
});
test('OIDC altered nonce (valid JWE) rejected after successful S256 grant',async()=>{
 const f=makeFixture(),flow=await start(f);await f.jar.reseal('nonce','wrong-cryptographically-sealed-nonce');
 const r=await callback(f,flow);noPositiveSession(r);
 assert.ok(f.idp.discovery>=2);assert.equal(f.idp.token,1);
 assert.equal(f.idp.attempts[0].verifierMatch,true);
 assert.equal(f.idp.successfulTokens,1);
});
test('OIDC ID Token nonce mismatch rejected after valid code/state/PKCE cookies',async()=>{
 const f=makeFixture({nonceOverride:'wrong-nonce-in-verified-claims'}),flow=await start(f);
 const r=await callback(f,flow);noPositiveSession(r);
 assert.equal(f.idp.token,1);assert.equal(f.idp.attempts[0].verifierMatch,true);
});
test('OIDC ID Token wrong audience refused despite correct state, nonce, PKCE',async()=>{
 const f=makeFixture({audOverride:'another-client'}),flow=await start(f);
 const r=await callback(f,flow);noPositiveSession(r);
 assert.equal(f.idp.token,1);assert.equal(f.idp.attempts[0].verifierMatch,true);
});
test('OIDC ID Token wrong issuer refused despite correct state, nonce, PKCE',async()=>{
 const f=makeFixture({issuerOverride:'https://untrusted.example.invalid'}),flow=await start(f);
 const r=await callback(f,flow);noPositiveSession(r);
 assert.equal(f.idp.token,1);assert.equal(f.idp.attempts[0].verifierMatch,true);
});
test('OIDC unknown callback code: passes state+PKCE but token endpoint denies it',async()=>{
 const f=makeFixture(),flow=await start(f);
 const r=await callback(f,flow,{code:'unknown-code'});noPositiveSession(r);
 assert.equal(f.idp.token,1);assert.equal(f.idp.successfulTokens,0);
 assert.equal(f.idp.attempts[0].code,'unknown-code');
});
test('OIDC replay: mock token endpoint prevents second redemption; cookies alone are not global replay protection',async()=>{
 const f=makeFixture(),flow=await start(f);const original=f.jar.clone();
 await proveSuccess(f,flow);
 const repeated=await callback(f,flow,{jar:original});noPositiveSession(repeated);
 assert.equal(f.idp.token,2);assert.equal(f.idp.successfulTokens,1);
 assert.equal(f.idp.attempts[1].replayed,true);
});
test('OIDC login POST with invalid CSRF cannot initiate the authorization request',async()=>{
 const f=makeFixture();
 const csrf=await f.send('/api/auth/csrf');f.jar.take(csrf);
 const r=await f.send('/api/auth/signin/google',{method:'POST',
   headers:f.jar.with({'content-type':'application/x-www-form-urlencoded',origin}),
   body:new URLSearchParams({csrfToken:'invalid-token',callbackUrl:origin+'/'}).toString()});
 assert.equal(f.idp.discovery,0);noPositiveSession(r);
 assert.equal(f.jar.has('pkce.code_verifier'),false);
});
