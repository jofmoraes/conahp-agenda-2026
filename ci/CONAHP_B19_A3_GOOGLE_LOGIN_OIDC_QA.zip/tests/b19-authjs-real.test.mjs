/** Mandatory real-library smoke for B19-B, no Google credentials or Google network needed.
 * Run only after an actual `npm ci` from lockfile; MUST NOT be counted as PASS without installed @auth/core@0.41.3.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {Auth} from '@auth/core';
import Google from '@auth/core/providers/google';
import {encode,decode} from '@auth/core/jwt';
import {makeAuthConfig,handleMe,authRequest} from '../lib/b19-core.mjs';
const origin='https://qa.example.invalid';
const sub='100000000000000000001';
const env={APP_ORIGIN:origin,AUTH_SECRET:'s'.repeat(64),AUTH_GOOGLE_ID:'no-real-google-client',AUTH_GOOGLE_SECRET:'no-real-google-secret',CONAHP_GOOGLE_BINDINGS_JSON:JSON.stringify([{sub,email:'qa@example.invalid',profileId:'flora'}])};
const cfg=()=>makeAuthConfig(env,Google);
const name='__Host-conahp.session-token';
const headerCookies=response=>response.headers.getSetCookie?.()||[response.headers.get('set-cookie')||''];
const extractCookie=(response,key)=>{
 const raw=headerCookies(response).find(v=>v.startsWith(`${key}=`));
 return raw?.split(';',1)[0]??null;
};
const makeReq=(path,init={})=>new Request(origin+path,init);

test('actual Auth.js Google provider config declares triple OAuth checks',()=>{
 const c=cfg();assert.equal(c.providers[0].id,'google');assert.deepEqual(c.providers[0].options.checks,['pkce','state','nonce']);
});
test('actual jwt.encode/decode JWE round-trip, tampering and expiry',async()=>{
 const payload={authProvider:'google',googleSub:sub,googleEmail:'qa@example.invalid',googleVerified:true};
 const jwe=await encode({token:payload,secret:env.AUTH_SECRET,salt:name,maxAge:60});
 const data=await decode({token:jwe,secret:env.AUTH_SECRET,salt:name});
 assert.equal(data.googleSub,sub);assert.equal(data.authProvider,'google');
 await assert.rejects(()=>decode({token:jwe.slice(0,-1)+'*',secret:env.AUTH_SECRET,salt:name}));
 const exp=await encode({token:payload,secret:env.AUTH_SECRET,salt:name,maxAge:-30});
 await assert.rejects(()=>decode({token:exp,secret:env.AUTH_SECRET,salt:name}));
});
test('actual JWE grants only server-bound profile, not query/email header spoof',async()=>{
 const jwe=await encode({token:{authProvider:'google',googleSub:sub,googleEmail:'qa@example.invalid',googleVerified:true},secret:env.AUTH_SECRET,salt:name,maxAge:3600});
 const response=await handleMe(makeReq('/api/me?profile=juliana',{headers:{cookie:`${name}=${jwe}`,'x-google-email':'juliana@example.invalid'}}),env,decode);
 assert.equal(response.status,200);assert.equal((await response.json()).profile.id,'flora');
});
test('actual Auth() providers, CSRF and anonymous session produce expected no-store responses',async()=>{
 const providers=await Auth(makeReq('/api/auth/providers'),cfg());
 assert.equal(providers.status,200);const data=await providers.json();assert.ok(data.google);assert.equal(data.google.id,'google');
 const csrf=await Auth(makeReq('/api/auth/csrf'),cfg());
 assert.equal(csrf.status,200);assert.ok((await csrf.json()).csrfToken);assert.ok(headerCookies(csrf).some(x=>x.includes('csrf-token')));
 const session=await Auth(makeReq('/api/auth/session'),cfg());
 assert.equal(session.status,200);assert.equal(await session.text(),'null');
});
test('actual Auth() /session reads JWT and issues renewed HttpOnly cookie, /me does not renew',async()=>{
 const payload={authProvider:'google',googleSub:sub,googleEmail:'qa@example.invalid',googleVerified:true};
 const jwe=await encode({token:payload,secret:env.AUTH_SECRET,salt:name,maxAge:30});
 const headers={cookie:`${name}=${jwe}`};
 const before=await handleMe(makeReq('/api/me',{headers}),env,decode);
 assert.equal(before.status,200);assert.equal(before.headers.get('set-cookie'),null);
 const session=await Auth(makeReq('/api/auth/session',{headers}),cfg());
 assert.equal(session.status,200);
 assert.ok(extractCookie(session,name),'GET /session must renew JWT session cookie');
 const cookie=headerCookies(session).find(x=>x.startsWith(`${name}=`));
 assert.match(cookie,/httponly/i);assert.match(cookie,/secure/i);assert.match(cookie,/samesite=lax/i);assert.match(cookie,/path=\//i);
 const renewed=extractCookie(session,name).split('=',2)[1];
 const data=await decode({token:renewed,secret:env.AUTH_SECRET,salt:name});
 assert.ok(data.exp>Math.floor(Date.now()/1000)+7*3600);
});
test('actual Auth() callback without required state cookie does not create session',async()=>{
 const forged=await Auth(makeReq('/api/auth/callback/google?state=forged&code=forged'),cfg());
 assert.notEqual(forged.status,200);
 assert.equal(headerCookies(forged).some(x=>x.startsWith(`${name}=`)&&!x.includes('Max-Age=0')),false);
});
test('actual Auth() signout POST requires CSRF proof and clears active session cookie',async()=>{
 const csrfResponse=await Auth(makeReq('/api/auth/csrf'),cfg());
 const {csrfToken}=await csrfResponse.json();
 const csrfCookie=extractCookie(csrfResponse,csrfResponse.headers.getSetCookie?.().find(v=>v.includes('csrf-token'))?.split('=')[0]||'__Host-authjs.csrf-token');
 assert.ok(csrfCookie,'csrf cookie from library');
 const payload={authProvider:'google',googleSub:sub,googleEmail:'qa@example.invalid',googleVerified:true};
 const jwe=await encode({token:payload,secret:env.AUTH_SECRET,salt:name,maxAge:3600});
 const post=(token)=>makeReq('/api/auth/signout',{method:'POST',headers:{cookie:`${csrfCookie}; ${name}=${jwe}`,'content-type':'application/x-www-form-urlencoded',origin},body:new URLSearchParams({csrfToken:token,callbackUrl:origin+'/'}).toString()});
 const invalid=await Auth(post('tampered'),cfg());
 assert.equal(headerCookies(invalid).some(v=>v.startsWith(`${name}=`)&&/max-age=0/i.test(v)),false,'tampered CSRF must not clear the valid session');
 const valid=await Auth(post(csrfToken),cfg());assert.ok([200,302,303].includes(valid.status));
 assert.ok(headerCookies(valid).some(v=>v.startsWith(`${name}=`)&&(/max-age=0/i.test(v)||/expires=Thu, 01 Jan 1970/i.test(v))));
});
