import test from 'node:test';
import assert from 'node:assert/strict';
import {bindingsFromEnv, resolveProfile, makeAuthConfig, authRequest, handleMe, handlePreferences, B19_POLICY} from '../lib/b19-core.mjs';

const origin = 'https://qa.example.invalid';
const subFlora='100000000000000000001', subJuliana='100000000000000000002';
const rows=[{sub:subFlora,email:'flora@example.invalid',profileId:'flora'},{sub:subJuliana,email:'juliana@example.invalid',profileId:'juliana'}];
const env={APP_ORIGIN:origin,AUTH_SECRET:'s'.repeat(64),AUTH_GOOGLE_ID:'synthetic-id',AUTH_GOOGLE_SECRET:'synthetic-secret',CONAHP_GOOGLE_BINDINGS_JSON:JSON.stringify(rows)};
const cookie='__Host-conahp.session-token';
const signed=(value)=>async()=>value;
const identity=(sub=subFlora,email='flora@example.invalid')=>({authProvider:'google',googleSub:sub,googleEmail:email,googleVerified:true,exp:Math.floor(Date.now()/1000)+28800});
const req=(p,init={})=>new Request(origin+p,init);
const withSession=(p,init={})=>req(p,{...init,headers:{cookie:`${cookie}=jwe-placeholder`,...init.headers}});

// These tests cover our policy, not Auth.js JWE/OIDC. Real-library cases are separate in test:authjs.
test('Q04: email-only binding is rejected at configuration time, even for verified mail',()=>{
 assert.throws(()=>bindingsFromEnv({...env,CONAHP_GOOGLE_BINDINGS_JSON:JSON.stringify([{email:'flora@example.invalid',profileId:'flora'}])}),/sub/);
 assert.equal(resolveProfile({sub:subFlora,email:'flora@example.invalid',emailVerified:true},[{email:'flora@example.invalid',profileId:'flora'}]),null);
});
test('Q04: sub-bound identity refuses other Google sub with same email',()=>{
 assert.equal(resolveProfile({sub:subFlora,email:'flora@example.invalid',emailVerified:true},rows)?.id,'flora');
 assert.equal(resolveProfile({sub:'900000000000000000009',email:'flora@example.invalid',emailVerified:true},rows),null);
});
test('Q04: verified Google sub alone can authorize with configured sub-only binding',()=>{
 const justSub=[{sub:subFlora,profileId:'flora'}];
 assert.deepEqual(resolveProfile({sub:subFlora,email:'flora@example.invalid',emailVerified:true},justSub),{id:'flora'});
 assert.equal(resolveProfile({sub:subFlora,email:'flora@example.invalid',emailVerified:false},justSub),null);
});
test('Q04: duplicate sub, duplicate profile, conflicting identity bindings all rejected',()=>{
 for(const bad of [[{sub:subFlora,profileId:'flora'},{sub:subFlora,profileId:'juliana'}], [{sub:subFlora,profileId:'flora'},{sub:subJuliana,profileId:'flora'}], [{sub:subFlora,email:'flora@example.invalid',profileId:'flora'},{sub:subJuliana,email:'FLORA@example.invalid',profileId:'juliana'}]])assert.throws(()=>bindingsFromEnv({...env,CONAHP_GOOGLE_BINDINGS_JSON:JSON.stringify(bad)}));
});
test('Q01: Google check policy declares PKCE, state and nonce, no weakened skip flag',()=>{
 let args;const config=makeAuthConfig(env,opts=>(args=opts,{id:'google',type:'oidc',checks:opts.checks}));
 assert.deepEqual(args.checks,['pkce','state','nonce']);assert.deepEqual(config.providers[0].checks,args.checks);
 assert.equal(config.skipCSRFCheck,undefined);assert.equal(config.useSecureCookies,undefined);
});
test('Q02: 8h JWT sliding session maximum; updateAge does not imply absolute timeout',()=>{
 const c=makeAuthConfig(env,opts=>({id:'google',...opts}));
 assert.equal(c.session.strategy,'jwt');assert.equal(c.session.maxAge,8*60*60);
 assert.equal(c.session.updateAge,undefined);assert.equal(B19_POLICY.sessionMaxSeconds,8*3600);
});
test('Q02: exp boundary is enforced for stale token after 8h without /session renewal',async()=>{
 const old={...identity(),exp:Math.floor(Date.now()/1000)-1};
 assert.equal((await handleMe(withSession('/api/me'),env,signed(old))).status,401);
 const active={...identity(),exp:Math.floor(Date.now()/1000)+25};
 assert.equal((await handleMe(withSession('/api/me'),env,signed(active))).status,200);
});
test('Q02: logout cannot be claimed as global revocation of a copied, still valid JWT',async()=>{
 // Auth.js signout clears the active browser cookie; a previously copied JWE stays decryptable until expiry.
 assert.equal((await handleMe(withSession('/api/me'),env,signed(identity()))).status,200);
 const unbound={...env,CONAHP_GOOGLE_BINDINGS_JSON:JSON.stringify([{sub:subJuliana,email:'juliana@example.invalid',profileId:'juliana'}])};
 assert.equal((await handleMe(withSession('/api/me'),unbound,signed(identity()))).status,403);
});
test('Q01: tampered callback values stay opaque and are not trusted by local path normalization',()=>{
 for(const values of ['state=evil&code=bogus','state=%2F%2Fattacker.invalid&code=fake','error=access_denied&state=changed']){
  const request=req('/api/auth?route=callback/google&'+values);
  const normalized=authRequest(request,env);
  assert.equal(new URL(normalized.url).pathname,'/api/auth/callback/google');
  assert.equal(new URL(normalized.url).searchParams.get('state'),new URL(request.url).searchParams.get('state'));
 }
 // The crypto validation occurs in Auth.js, deliberately not pretended by this local normalizer.
});
test('Q01: callback route cannot be replaced by arbitrary provider or traversal',()=>{
 for(const route of ['callback/evil','callback/google/../../preferences','callback/google%2F../../me']){
  assert.equal(authRequest(req('/api/auth?route='+route),env),null);
 }
});
test('Q04: spoofed browser profile and Google headers do not select profile',async()=>{
 const response=await handleMe(withSession('/api/me?profile=juliana',{headers:{'x-google-sub':subJuliana,'x-profile-id':'juliana'}}),env,signed(identity()));
 assert.equal(response.status,200);assert.equal((await response.json()).profile.id,'flora');
});
test('Q04: unknown account cannot see, write or impersonate Juliana preferences',async()=>{
 const unknown=signed(identity('900000000000000000009','flora@example.invalid'));
 assert.equal((await handleMe(withSession('/api/me'),env,unknown)).status,403);
 assert.equal((await handlePreferences(withSession('/api/preferences',{method:'POST',headers:{origin,'content-type':'application/json'},body:'{"profileId":"juliana"}'}),env,unknown)).status,403);
});
test('Q04: GET/POST preferences remain unavailable even for allowed account, until B20',async()=>{
 const good=signed(identity());
 assert.equal((await handlePreferences(withSession('/api/preferences'),env,good)).status,503);
 assert.equal((await handlePreferences(withSession('/api/preferences',{method:'POST',headers:{origin,'content-type':'application/json'},body:'{"profileId":"juliana"}'}),env,good)).status,503);
});
