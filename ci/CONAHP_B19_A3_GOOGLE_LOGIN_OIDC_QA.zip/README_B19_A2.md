# B19-A2 - remediação segura de Google OIDC

Overlay de autenticação isolado, baseado em B19-A SHA-256 `e411cc6c751132e11320d40c389d67b5db0739f4eca449f2688f58c8c5764a0a` e código B18-K commit `5aae37ea87783d43546a6351d04ffa1b6bdc2697`. Nenhum arquivo `public/` incluído. A versão estável B18-J não foi alterada.

**Status honesto: `B19_A2_BLOCKED_EXTERNAL_NPM` para a comprovação integral Q03.** As correções de código de Q01/Q02/Q04 e os testes sintéticos passaram; a instalação/execução do pacote npm 0.41.3 continua NOT_RUN por DNS. O pacote contém lockfile derivado de registros públicos para reprodução, ainda não validado por `npm ci`. Não publicar preview nem inferir login real.

Executar localmente `npm test`, `npm run check` (sem dependências); após lib instalada de verdade em runtime com acesso npm e após uma verificação de lockfile: `npm ci --ignore-scripts`, `npm run test:authjs`, `npm test`, `npm run check`. Para QA em navegador e Google OAuth real, autorização separada B19-B é obrigatória.

Ver `docs/B19_A2_DELTA_QA.md`, `docs/B19_A2_LOCKFILE_PROVENANCE.md`, `docs/B19_A2_OWNER_GATE.md`.
