import {decode} from '@auth/core/jwt';
import {handlePreferences} from '../lib/b19-core.mjs';
export default async function handler(request){return handlePreferences(request,process.env,decode);}
