import {decode} from '@auth/core/jwt';
import {handleMe} from '../lib/b19-core.mjs';
export default async function handler(request){return handleMe(request,process.env,decode);}
