import {Auth} from '@auth/core';
import Google from '@auth/core/providers/google';
import {authRequest,makeAuthConfig,hasAuthConfig,error} from '../lib/b19-core.mjs';
export default async function handler(request){
  if(!hasAuthConfig(process.env))return error(503,'AUTH_NOT_CONFIGURED','Autenticação indisponível');
  try {
    const normalized=authRequest(request,process.env);
    if(!normalized)return error(404,'AUTH_ROUTE_NOT_FOUND','Rota não encontrada');
    const response=await Auth(normalized,makeAuthConfig(process.env,Google));
    response.headers.set('Cache-Control','no-store');
    return response;
  }catch{
    return error(503,'IDENTITY_UNAVAILABLE','Autenticação indisponível');
  }
}
