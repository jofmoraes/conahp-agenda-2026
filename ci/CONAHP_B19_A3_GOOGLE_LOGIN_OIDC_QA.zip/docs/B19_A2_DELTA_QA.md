# CONAHP B19-A2 - Delta auditável pós B19-Q

Fonte B19-Q [GitHub Issue #3, comentário 6218783001](https://github.com/jofmoraes/conahp-agenda-2026/issues/3#issuecomment-6218783001); decisão B19-A2 comentário 6218885547. O pacote B19-A original (sha256 e411cc6c751132e11320d40c389d67b5db0739f4eca449f2688f58c8c5764a0a) é preservado; este overlay substitui somente sua versão de autenticação, sem `public/`.

## Mudanças e status

**P1-Q01 (implementado, PASS estático/sintético; runtime NOT_RUN)**: `Google({clientId,clientSecret,checks:['pkce','state','nonce']})` explícito. Confirmação em código-fonte tag oficial `@auth/core@0.41.3`, `packages/core/src/lib/utils/providers.ts`, `signin/authorization-url.ts`, `callback/oauth/checks.ts`: lib aceita triple checks e emite cookies criptografados específicos do provider, challenge S256, state e nonce quando configurados. Testes sintéticos asseguram opts e normalização; callback adulterado **não foi criptograficamente exercitado**, porque npm não está instalado. Teste de Auth.js real preparado em `tests/b19-authjs-real.test.mjs`, executar após npm ci e ajustar se necessário. Nenhum teste sintético é apresentado como prova de consumo de checks real.

**P1-Q02 (implementado/documentado, PASS sintético; Auth.js real NOT_RUN)**: `session.strategy='jwt'`, `maxAge=28800` (oito horas), sem `updateAge` inválido/irrelevante para JWT. Fonte tag `packages/core/src/lib/actions/session.ts`: a requisição válida `GET /api/auth/session` **renova** expiração/cookie; `GET /api/me` apenas lê sem renovar. Sem chamar `/session`, expira 8h após emissão/última renovação, não existe tempo máximo absoluto fixado desde o login. Sair limpa cookie do navegador; cópia válida anterior não tem revogação global instantânea, salvo perda do binding/rotação de segredo e possível store futuro. Teste real de renovação cookie/JWE e signout incluído, mas NÃO EXECUTADO. Frontend B18 não invoca rota de sessão, portanto não há renovação programada nesta etapa; UI B19-I decidirá quando consultar sessão e experiência ao expirar.

**P1-Q03 (parcial, bloqueio externo DNS npm)**: `package-lock.json` lockfileVersion 3 e versões exatas/hashes SHA512 obtidos de dois `package-lock.json` públicos de projetos alheios e comparados; **arquivo foi montado e revisado offline**. Não afirmamos que npm gerou ou validou este lockfile. `npm view @auth/core@0.41.3` falhou `EAI_AGAIN`; `npm ci --offline` falhou `ENOTCACHED` porque tarballs não estão em cache. `npm ci` em rede e `npm run test:authjs` real **NOT_RUN**. Não criar `node_modules` fictício, dependência vendorizada sem proveniência ou lockfile apresentado como validado. Bloco B19-B precisa de um runtime com acesso DNS/HTTPS `registry.npmjs.org`, `npm ci --ignore-scripts`, `npm run test:authjs`, validação de rewrites Functions, e só então autorização adicional de preview/Google Cloud.

**P1-Q04 (implementado, PASS testes locais)**: linha de `CONAHP_GOOGLE_BINDINGS_JSON` exige `sub` Google **exato**, `profileId` único, email opcional **somente como condição adicional**; sem linha só com email, sem cadastro automático, sem fallback ou client `profileId`. `resolveProfile` exige `email_verified:true` e vínculo `sub`; cada GET/POST privado reavalia binding. Cadastro/controlado de `sub` sob revisão humana futura, apenas em variáveis protegidas da Preview (não nesta missão). Binding desconhecido/mudado nega e perfil forjado não tem efeito. Nenhum usuário real provisionado.

## Matriz de execução

| Comando ou evidência | Resultado |
|---|---|
| `npm test` Node 22.16.0 | PASS 40/40, 0 FAIL, casos 27 anteriores atualizados + 13 novos |
| `npm run check` | PASS |
| `node --check tests/b19-authjs-real.test.mjs` | PASS (sintaxe, **não** import/runtime) |
| `npm view @auth/core@0.41.3` | BLOCKED_EXTERNAL EAI_AGAIN DNS |
| `npm ci --offline` | BLOCKED_EXTERNAL ENOTCACHED |
| `npm ci` conectado, `npm run test:authjs` (Auth, JWT, cookie, OAuth callback) | NOT_RUN devido a dependência indisponível |
| Google login/ID Token real, logout, refresh, OAuth redirect e callbacks reais | NOT_RUN (sem credenciais nem preview autorizada) |
| Vercel rewrites reais, Safari/iOS PWA instalada, Android, Google Sheets/B20 | NOT_RUN |
| Código da Flora, localStorage, backups e alias B18-J | Sem qualquer alteração; alias readback READ-ONLY B18-J |

Não assumir ausência de riscos por zero falhas sintéticas. `test:authjs` inclui casos de callback inválido, JWE real, refresh de cookie e logout; qualquer falha dessa bateria em ambiente npm acessível deve ser corrigida antes de propor B19-B. A auditoria B19-Q deve distinguir melhoria de segurança local vs engenharia dependente de pacotes/rede.

## Gestão do escopo

Sem alteração de `public/`, preferências, backup, Sheets, Apps Script, Cloudflare, Google Cloud, env vars, Vercel deployment/alias, GitHub branch/PR/merge ou outros projetos. O pacote é overlay de arquivos de código e documentação, ainda não um app publicado. No rollback local, reverter apenas o overlay para B19-A ou removê-lo integralmente; versão estável B18-J segue intocada.
