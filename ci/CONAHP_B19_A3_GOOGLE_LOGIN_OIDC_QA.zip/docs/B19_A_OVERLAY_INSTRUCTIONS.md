# NOTA B19-A2: pacote overlay A2 substitui A; contém lockfile de proveniência externa, **não testado com npm ci** por DNS. `npm run test:authjs` é a prova pendente.

# How an authorized B19-B engineer reproduces this candidate (NOT an instruction to deploy)

1. Obtain clean source of `feat/b18-flora-ux` at exact SHA `5aae37ea87783d43546a6351d04ffa1b6bdc2697` from GitHub. Do **not** use current `main` (old B15 doc state).
2. Extract this B19-A ZIP into a staging folder, not over the user's app or PWA. It is an **overlay only**, intentionally containing no `public/` file. With authorization for local integration, copy `api/`, `lib/`, `package.json`, `vercel.json`, `tests/b19-auth.test.mjs`, `docs/B19_A_*` to the checkout. Do not overwrite B18 source files. Add the B19-A section to `docs/DELIVERY.md` from `docs/B19_A_DELIVERY_ADDENDUM.md` and keep B18 history unchanged. No change to any existing `localStorage` key/backup.
3. In an environment with npm connectivity, use the pinned `@auth/core@0.41.3` and verify the included `package-lock.json` and re-resolve it with authorized npm registry access, run `npm ci`, `npm test`, `npm run check`, and a direct Auth.js `Auth(request, config)` test with mocked OIDC responses. The present ZIP **does not carry node_modules (the B19-A2 package includes a provenance-documented lockfile)** because registry DNS was inaccessible. Pin package transitive versions for a reproducible B19-B build.
4. Validate Vercel rewrites in a nonproduction isolated preview; Auth.js callback and cookie paths must match `APP_ORIGIN`. Block promotion if `api/auth.js` cannot be invoked at `/api/auth/callback/google`, CSRF fails, or session cookie is absent in Safari PWA. Always test anonymous agenda and read/write denial.
5. B19-I may add an opt-in login button, but must not replace or clear B18 local data. B20 owns remote preference implementation and migration, not B19-A.

Current output: code/tests/decisions only. Not a complete runnable B18 distribution and not a preview deployment. ZIP SHA-256 and file hashes are recorded in its `B19_A_MANIFEST.json`, with GitHub source SHA pinned above.
