## 2026-10-16 - B19-A2 - remediação pós auditoria B19-Q
- Fonte: B19-A ZIP e commit B18-K `5aae37ea87783d43546a6351d04ffa1b6bdc2697`; sem mudanças `public/`, produção, localStorage/backup.
- Alterado: `checks` explícitos `[pkce,state,nonce]`, sessão JWT renovável 8h (não absoluta), vínculo obrigatório por Google sub e negação de email-only bootstrap; adicionado testes negativos e teste de integração Auth.js real para execução futura.
- Lockfile v3 com integridades obtidas de lockfiles públicos, **não validado por npm ci**. P1-Q03 permanece externo por DNS EAI_AGAIN/ENOTCACHED; teste Auth.js real NOT_RUN, nenhuma autenticação real homologada.
- QA sintético `npm test` 40/40 PASS; `npm run check` PASS. Gate: acesso npm para instalar/testar biblioteca antes de autorização B19-B preview/Google Cloud; auditoria independente de delta.
- Fonte durável do estado: Issue #3 fechamento B19-A2; artefato ZIP no Google Drive.
