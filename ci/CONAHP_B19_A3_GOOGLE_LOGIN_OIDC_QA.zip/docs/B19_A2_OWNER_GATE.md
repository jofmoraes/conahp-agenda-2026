# B19-A2 - gate mínimo futuro (não executar sem autorização)

Primeiro, o auditor B19-Q revisa o delta e distingue Q03 bloqueado por DNS. Antes de solicitar alterações de serviços, concluir engenharia de instalação: usar ambiente isolado com acesso à registry npm, `npm ci`, `npm test`, `npm run test:authjs`, validar lockfile e corrigir qualquer falha de runtime, sem Codex/Work não autorizados. Se isso exigir atuação externa, solicitar permissão específica.

Depois de PASS local real e decisão B19-B separada do proprietário:

1. Escolher hostname HTTPS de preview estável **diferente** de `conahp-flora-2026.vercel.app`, no projeto/ambiente isolado sem ligação de alias estável e sem CI autodeploy. Não presumir que push não faz deploy.
2. Google Cloud Console > projeto autorizado > Google Auth Platform > Branding/Audience > Externo/teste > contas QA; apenas scopes básicos `openid email profile`.
3. Google Auth Platform > Clients > OAuth client ID > Web application > **Authorized redirect URI** exatamente `https://HOST-QA/api/auth/callback/google` (HOST-QA a ser preenchido somente após criação autorizada). Credenciais não entram no GitHub nem em chat.
4. Vercel Dashboard > projeto QA aprovado > Settings > Environment Variables > Preview/escopo restrito: `APP_ORIGIN` HTTPS exata sem barra final, `AUTH_GOOGLE_ID`, `AUTH_GOOGLE_SECRET`, `AUTH_SECRET` >=32 caracteres aleatórios, `CONAHP_GOOGLE_BINDINGS_JSON` JSON com `sub` obtido/verificado de modo autorizado e `profileId` aprovado; email pode ser restrição adicional mas **não** substitui o sub. Não copiar conta real para exemplos públicos.
5. Upload/deploy de preview **somente após aprovação específica**, verificando `/api/auth/csrf`, providers, signin, callback, sessão 8h deslizante, logout e negações para contas não vinculadas, CSRF/state/PKCE/nonce adulterados, `/api/me` perfil certo e `/api/preferences` ainda 503. Validar anônimo `/schedule.json` e tela B18, cookies no Chrome/Android e Safari/iPhone incluindo PWA instalada e retorno ao aplicativo.
6. Nenhuma limpeza/reinstalação de PWA ou migração automática: preservar `conahp2026:flora:preferences:b18`, `conahp2026:public-filters:v1`, `conahp2026:b18:legacy-snapshot:v1`; B20 fará backup/consentimento/reconciliação por sessão sob autorização independente.
7. Mesmo que login em preview dê PASS, não promover alias da Flora antes de B20 persistência real e decisão final, mantendo rollback B18-J `dpl_HdVB9FKzCLFUnYwwuU9d7LHpkCtW`.
