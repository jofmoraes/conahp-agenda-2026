# B19-A3 - OAuth/OIDC controlado e isolamento de fases de falha

## Escopo e origem

- Origem imutável: B19-A2 ZIP SHA-256 `2ab83d9b582b3f36c1703db26e8470beb9ddf20dac481b312668b19d387d1b6d`.
- `@auth/core@0.41.3` e o mesmo `package-lock.json` da B19-A2, o qual `npm ci` validou no GitHub Actions `38930909122`.
- Fonte de aplicação inalterada: `api/auth.js`, `api/me.js`, `api/preferences.js`, `lib/b19-core.mjs` e `vercel.json` byte-idênticos ao A2; `public/` totalmente ausente.
- Correção de teste canônica de `providers[0].checks` para `providers[0].options.checks` sem mudança da configuração real (`checks=['pkce','state','nonce']`). O Google factory guarda as opções até normalização pelo Auth.js.
- Runner anterior CI [38930909122](https://github.com/jofmoraes/conahp-agenda-2026/actions/runs/38930909122): `npm ci` PASS, biblioteca Auth.js real instalada, 7/7 testes anteriores PASS após correção da assertiva **apenas no runner**, 40/40 sintéticos PASS, `npm audit` 0 vulnerabilidades. Isso não prova a nova suíte.

## Projeto da suíte controlada

Arquivo novo `tests/b19-oidc-controlled.test.mjs` (13 testes). Importa **Auth, customFetch** e **@auth/core/jwt** reais, com a mesma configuração `makeAuthConfig(env,Google)` de produção, alterando *somente a opção `customFetch` do provider durante o teste*. `customFetch` é API pública do pacote, apropriada para mock de endpoints. Nenhuma alteração/bypass de callbacks, OIDC checks ou criptografia da aplicação. Origem de app `https://qa.example.invalid`; issuer de discovery simulado `https://accounts.google.com`, sem conexão a essa origem; endpoints simulados em `https://oidc-fixture.example.invalid`, sem conexão externa.

A função fake responde discovery com URL de authorization, token, userinfo, JWKS e **`code_challenge_methods_supported:['S256']` obrigatório** para evitar a lógica do Auth.js de desabilitar PKCE diante de servidor que não anuncia S256. Expõe certificado JWKS público sintético de RSA-2048 e assina ID Token de teste via Node crypto; sub, email e credenciais são exclusivamente fictícios. Verifica validade criptográfica **da fixture criada** usando o JWKS. O Auth.js processa validação dos claims do ID Token no fluxo backchannel `processAuthorizationCodeResponse`; **não** atribuir a ele verificação da assinatura RSA da fixture, pois `oauth4webapi` distingue essa validação opcional da validação OIDC de claims com transporte confiável.

O fluxo inicia em `Auth(GET /api/auth/csrf)` -> `Auth(POST /api/auth/signin/google)` -> 302 authorize; verifica `state`, `nonce`, `code_challenge`, `code_challenge_method=S256`, 3 cookies efetivos e *decode real* dos cookies selados, comparando seus valores aos parâmetros e o SHA-256 base64url do `code_verifier` ao challenge. O mock registra um código **de uso único** vinculado aos parâmetros emitidos. O callback `Auth(GET /api/auth/callback/google?state=...&code=...)` faz discovery efetivamente mockado, valida `state`, recupera `code_verifier`, alcança endpoint token fake, compara S256 (401/400 `invalid_grant` em divergência), valida nonce/claims OIDC, aplica `signIn`/allowlist `sub`+e-mail verificado e produz cookie de sessão JWE. O teste decifra JWE com a **biblioteca Auth.js real**, acessa `/api/me` com profile forjado e confirma que apenas `flora` é resolvida; `/api/preferences` retorna 503 até B20.

### Matriz nova de 13 casos (a executar com npm real)

1. **Sucesso completo**: CSRF, authorize, 3 checks e cookies, S256, callback, ID Token sintético, cookie de sessão, perfil server-side e recusa de persistência.
2. **State query adulterado**: discovery conclui; callback rejeita **antes** de qualquer chamada token.
3. **State cookie ausente**: discovery conclui; nenhuma troca de token.
4. **PKCE cookie ausente**: state enviado corretamente, discovery conclui, token não é chamado.
5. **PKCE cookie selado mas com verifier diferente**: fake token é **efetivamente chamado** e compara `SHA-256(code_verifier)` contra challenge original, retornando `invalid_grant`.
6. **Nonce cookie ausente**: discovery e token chamados, S256 aprovado, sem sessão por falha de nonce.
7. **Nonce cookie selado mas alterado**: discovery e token chamados, S256 aprovado, nonce inesperado rejeitado no processamento OIDC.
8. **Nonce claim no ID Token divergente**: token entrega ID Token, Auth.js rejeita após S256 válido.
9. **Audience divergente**: troca de token com S256 válido, claim `aud` rejeitado.
10. **Issuer divergente**: troca de token com S256 válido, claim `iss` rejeitado.
11. **Code desconhecido**: state+PKCE passam, token endpoint fake devolve `invalid_grant`.
12. **Replay**: primeira troca gera sessão; segundo callback com **cookies antigos preservados** tenta redimir mesmo code, mock do emissor nega pelo código de uso único, nenhuma segunda sessão. **Não atribuir ao state cookie revogação global ou defesa de replay do token servidor.**
13. **CSRF inicial inválido**: POST sign-in não chega ao discovery nem cria PKCE/cookies OAuth.

**Controle de falsos PASS:** cada negativo exige descoberta mockada (quando etapa já alcançada) e contagens específicas de acesso ao endpoint token, sucesso na verificação S256 de grant ou incompatibilidade S256, e ausência de novo cookie autenticado. `customFetch` rejeita imediatamente qualquer URL OIDC não prevista; callbacks não podem passar *apenas* por falha de DNS real. Um teste de positivo completo precisa PASS antes de qualquer inferência de força dos negativos. Os novos testes **não foram executados nesta sandbox**: a dependência real continua ausente por `EAI_AGAIN`. Eventuais falhas de implementação da fixture ou semântica Auth.js no runner devem ser corrigidas, retestadas e reportadas com novo SHA: nenhuma verificação nova foi falsamente declarada PASS.

## Limites e segurança

- `state`, PKCE e `nonce` são três checks distintos, cada um com teste individual. Códigos de authorization replay são do **emissor OIDC**, sem nonce-cookies globais nem revogação de sessão JWE copiada.
- `maxAge=28800` (8h) é janela **renovável** ao consultar `/api/auth/session`, não prazo absoluto desde o primeiro login; `/api/me` não renova. Logout elimina cookie daquele navegador, não JWT roubado antes do exp.
- A versão estável B18-J e todos os dados locais são mantidos; API de preferência segue fail-closed até B20. Nenhuma conta Google verdadeira ou login HTTPS de smartphone foram utilizados.
- QA em Safari/iPhone PWA, Android PWA, Google Cloud, Vercel preview/rewrites, persistência Sheets e B20 permanecem gates externos autorizados separadamente.
