# B19-A3 - execução mínima pelo orquestrador em ambiente temporário existente

**Não executar novo workflow/Actions automaticamente por esta entrega.** Orquestrador pode optar por reutilizar runner previamente autorizado após conferir que nenhuma publicação pode ser disparada. Este documento é só handoff.

1. Fazer download de `CONAHP_B19_A3_GOOGLE_LOGIN_OIDC_QA.zip` no Drive oficial; calcular SHA-256 fornecido no comentário Issue, verificar CRC e hashes do manifesto. Não aplicar B19-A3 na branch funcional da Flora nem na main.
2. Extrair ZIP em pasta isolada, sem secrets, sem Google Cloud e sem acesso à planilha. Rodar Node 22 ou 24, `npm ci --ignore-scripts --no-audit --no-fund`, `npm ls @auth/core` (esperado 0.41.3), `npm run test:authjs` (**20 testes reais pretendidos: 7 anteriores + 13 novos**), `npm test` (**40 testes sintéticos**) e `npm run check`.
3. `npm audit --omit=dev --audit-level=high` se desejado, registrar separadamente; não inferir o resultado audit anterior da versão de dependência sem rechecagem.
4. Salvar saídas textuais apenas dos testes e hashes; não coletar cookies nem JWTs, mesmo sintéticos, desnecessariamente. Reportar número PASS/FAIL com *stack trace* sanitizado para correção se houver falha. Uma falha em qualquer teste OIDC novo significa **B19-A3 ainda não homologado**, não fazer deploy.
5. Confirmar que o smoke antigo com `providers[0].options.checks` PASS e novo controlled OIDC flow chega a discovery e token fake antes de aceitar negativos; validar nenhum pedido HTTP saiu para o Google real.
6. Após testes reais PASS, auditor B19-Q realiza auditoria de delta se requerida; **B19-B exige nova autorização** para OAuth Google real/hostname Preview/secrets/deploy. Nada promove alias `conahp-flora-2026.vercel.app` antes do B20 Sheets, migração assistida e gate explícito.

**Readback autorizado apenas para verificação:** a release estável Flora B18-J era `dpl_HdVB9FKzCLFUnYwwuU9d7LHpkCtW`, branch B18-K `5aae37ea87783d43546a6351d04ffa1b6bdc2697`; confirmar novamente caso haja operação futura, mas esta missão não realizou operações Vercel.
