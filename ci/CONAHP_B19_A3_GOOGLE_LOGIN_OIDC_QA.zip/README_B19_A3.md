# CONAHP B19-A3 - Overlay Auth.js para QA de OAuth/OIDC controlado

**Natureza:** pacote isolado, aplicação Google OAuth na Vercel **não implantada**. Sobrepor somente numa cópia da árvore B18-K `5aae37ea87783d43546a6351d04ffa1b6bdc2697` se houver autorização futura. Este ZIP não contém `public/`, não modifica B18-J estável, não migra/limpa preferências locais e não contém contas, segredos nem dados reais.

Base exata: B19-A2 ZIP SHA256 `2ab83d9b582b3f36c1703db26e8470beb9ddf20dac481b312668b19d387d1b6d`. `@auth/core` fixado em `0.41.3`; `package-lock.json` **byte a byte igual ao B19-A2 validado por `npm ci` no run anterior**. Nenhuma lógica de produção `api/`, `lib/`, `vercel.json` foi alterada na B19-A3.

Delta: assertiva corrigida em `tests/b19-authjs-real.test.mjs` para `.providers[0].options.checks`, novo `tests/b19-oidc-controlled.test.mjs` com **13 testes de integração usando a biblioteca real e provedora OIDC 100% em memória**, scripts de teste atualizados, documentação e manifesto. O simulador usa `customFetch` documentado do Auth.js apenas nos testes, substitui discovery e token pelo provider fake com emissão de ID Token RS256 **sintético**, nunca envia requisição ao Google. A validação da assinatura da fixture RSA é teste separado; não afirmar que o Auth.js a valida em token backchannel, onde há verificação dos claims OIDC e confiança na conexão TLS da origem.

**Como testar quando houver npm instalado (não disparar automaticamente Actions):**

```
npm ci --ignore-scripts --no-audit --no-fund
npm ls @auth/core
npm run test:authjs
npm test
npm run check
npm audit --omit=dev
```

**Status:** `B19_A3_READY_FOR_REAL_OIDC_QA` significa **pronto para executar a nova suíte em runner autorizado**, NÃO testes OIDC novos PASS. Evidência histórica de Auth.js instalado, 7/7 testes reais legados PASS, 40/40 políticas PASS e audit 0: GitHub Actions run [38930909122](https://github.com/jofmoraes/conahp-agenda-2026/actions/runs/38930909122). Nesta execução GPT Web local a dependência não pôde ser instalada (`EAI_AGAIN registry.npmjs.org`); novos 13 testes ficaram **NOT_RUN**. Consultar `docs/B19_A3_OIDC_QA.md`, `docs/B19_A3_RUNNER_GATE.md` e `B19_A3_MANIFEST.json` para o detalhamento dos limites/gates.
